场景	                            MainActivity 生命周期顺序	              目标 Activity 生命周期顺序
应用启动	                    onCreate() → onStart() → onResume()	                      |
Main → SecondActivity	               onPause() → onStop()	             onCreate() → onStart() → onResume()
SecondActivity 返回	           onRestart() → onStart() → onResume()	      onPause() → onStop() → onDestroy()
Main → Dialog Activity	                   onPause()	                  onCreate() → onStart() → onResume()
Dialog Activity 返回	                   onResume()	                   onPause() → onStop() → onDestroy()