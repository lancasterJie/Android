package com.example.test;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RotateActivity extends AppCompatActivity {
    private static final String TAG = "RotateActivity";
    private static final String KEY_SAVED_TEXT = "saved_text";
    private EditText etInput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_rotate);
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG, "onSaveInstanceState - 在onStop之前，onPause之后调用");
        etInput = findViewById(R.id.etInput);

        String inputText = etInput.getText().toString();
        if (!inputText.isEmpty()) {
            outState.putString(KEY_SAVED_TEXT, inputText);
            Log.d(TAG, "保存EditText内容: " + inputText);
        }
    }
}