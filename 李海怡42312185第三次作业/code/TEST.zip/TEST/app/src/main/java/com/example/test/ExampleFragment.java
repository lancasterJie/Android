package com.example.test;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ExampleFragment extends Fragment {

    private OnFragmentInteractionListener listener;

    public interface OnFragmentInteractionListener {
        void onDataReceived(String data);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 设置Activity必须实现接口
        if (getActivity() instanceof OnFragmentInteractionListener) {
            listener = (OnFragmentInteractionListener) getActivity();
        } else {
            throw new RuntimeException(getActivity().toString() + "必须实现OnFragmentInteractionListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_example, container, false);

        // 获取从Activity传递的初始数据
        Bundle args = getArguments();
        if (args != null) {
            String initialData = args.getString("initial_data");
            int initialNumber = args.getInt("initial_number");

            TextView tvInitialData = view.findViewById(R.id.tvInitialData);
            tvInitialData.setText(String.format("初始数据: %s\n数字: %d", initialData, initialNumber));
        }

        EditText etFragmentInput = view.findViewById(R.id.etFragmentInput);
        Button btnSendToActivity = view.findViewById(R.id.btnSendToActivity);

        btnSendToActivity.setOnClickListener(v -> {
            String inputData = etFragmentInput.getText().toString();
            if (!inputData.isEmpty()) {
                // 通过接口将数据返回给Activity
                listener.onDataReceived(inputData);
            }
        });

        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}