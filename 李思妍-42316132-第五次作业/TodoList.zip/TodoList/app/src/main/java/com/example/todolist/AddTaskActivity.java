package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {

    private EditText taskNameEditText;
    private EditText dueDateEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        // 初始化视图
        taskNameEditText = findViewById(R.id.taskNameEditText);
        dueDateEditText = findViewById(R.id.dueDateEditText);
        Button cancelButton = findViewById(R.id.cancelButton);
        Button saveButton = findViewById(R.id.saveButton);

        // 取消按钮点击事件
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 关闭当前Activity，返回上一个界面
            }
        });

        // 保存按钮点击事件
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });
    }

    private void saveTask() {
        String taskName = taskNameEditText.getText().toString().trim();
        String dueDate = dueDateEditText.getText().toString().trim();

        // 验证输入
        if (taskName.isEmpty()) {
            Toast.makeText(this, "请输入任务名称", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dueDate.isEmpty()) {
            Toast.makeText(this, "请输入截止日期", Toast.LENGTH_SHORT).show();
            return;
        }

        // 创建Intent返回数据
        Intent resultIntent = new Intent();
        resultIntent.putExtra("taskName", taskName);
        resultIntent.putExtra("dueDate", dueDate);

        // 设置结果并关闭Activity
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}