package com.example.todolist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<TaskItem> {

    private ArrayList<TaskItem> tasks;

    public TaskAdapter(Context context, ArrayList<TaskItem> tasks) {
        super(context, 0, tasks);
        this.tasks = tasks;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // 获取当前任务项
        final TaskItem task = getItem(position);

        // 检查视图是否被重用，否则填充视图
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_task, parent, false);
        }

        // 获取视图中的 TextView 和 Button
        TextView taskNameTextView = convertView.findViewById(R.id.taskNameTextView);
        TextView dueDateTextView = convertView.findViewById(R.id.dueDateTextView);
        Button deleteButton = convertView.findViewById(R.id.deleteButton);

        // 设置任务数据
        if (task != null) {
            taskNameTextView.setText(task.getTaskName());
            dueDateTextView.setText("截止日期: " + task.getDueDate());
        }

        // 设置删除按钮点击事件
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 移除任务
                tasks.remove(position);
                // 通知适配器数据已改变
                notifyDataSetChanged();
            }
        });

        return convertView;
    }
}