package com.example.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<TaskItem> tasks;
    private TaskAdapter adapter;
    private static final int ADD_TASK_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化任务列表数据
        tasks = new ArrayList<>();
        tasks.add(new TaskItem("Complete Android Homework", "2025-12-20"));
        tasks.add(new TaskItem("Buy groceries", "2024-05-01"));
        tasks.add(new TaskItem("Walk the dog", "2024-04-20"));
        tasks.add(new TaskItem("Call John", "2024-04-23"));

        // 创建自定义适配器
        adapter = new TaskAdapter(this, tasks);

        // 获取 ListView 并设置适配器
        ListView listView = findViewById(R.id.taskListView);
        listView.setAdapter(adapter);

        // 添加列表项点击事件
        listView.setOnItemClickListener((parent, view, position, id) -> {
            TaskItem selectedTask = tasks.get(position);
            String message = "选中任务: " + selectedTask.getTaskName() +
                    "\n截止日期: " + selectedTask.getDueDate();
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        });

        // 添加新任务按钮点击事件
        Button addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动添加任务的Activity
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivityForResult(intent, ADD_TASK_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_TASK_REQUEST && resultCode == RESULT_OK) {
            // 获取返回的数据
            String taskName = data.getStringExtra("taskName");
            String dueDate = data.getStringExtra("dueDate");

            // 添加到任务列表
            tasks.add(new TaskItem(taskName, dueDate));

            // 通知适配器数据已改变
            adapter.notifyDataSetChanged();

            Toast.makeText(this, "任务添加成功", Toast.LENGTH_SHORT).show();
        }
    }
}