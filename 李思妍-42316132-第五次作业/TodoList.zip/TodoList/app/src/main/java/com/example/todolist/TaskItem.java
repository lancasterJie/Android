package com.example.todolist;

public class TaskItem {
    private String taskName;
    private String dueDate;

    // 构造函数
    public TaskItem(String taskName, String dueDate) {
        this.taskName = taskName;
        this.dueDate = dueDate;
    }

    // Getter 方法
    public String getTaskName() {
        return taskName;
    }

    public String getDueDate() {
        return dueDate;
    }

    // Setter 方法
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}