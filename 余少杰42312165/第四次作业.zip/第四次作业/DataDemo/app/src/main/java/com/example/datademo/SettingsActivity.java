package com.example.datademo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private CheckBox cbAutoSave;
    private EditText etUserName, etPassword;
    private Button btnLogin, btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        setTitle("设置");

        cbAutoSave = findViewById(R.id.cbAutoSave);
        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnSave = findViewById(R.id.btnSave);

        loadPreferences();

        btnSave.setOnClickListener(v -> savePreferences());

        btnLogin.setOnClickListener(v -> {
            String userName = etUserName.getText().toString();
            String password = etPassword.getText().toString();

            if (userName.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "请输入用户名和密码", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userName.equals("余少杰") && password.equals("42312165")) {
                Toast.makeText(this, "登录成功", Toast.LENGTH_SHORT).show();
                savePreferences();
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void savePreferences() {
        SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        editor.putBoolean("auto_save", cbAutoSave.isChecked());
        editor.putString("user_name", etUserName.getText().toString());
        editor.putString("passwd", etPassword.getText().toString());
        editor.apply();

        Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show();
    }

    private void loadPreferences() {
        SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);

        boolean autoSave = sp.getBoolean("auto_save", false);
        String userName = sp.getString("user_name", "");
        String password = sp.getString("passwd", "");

        cbAutoSave.setChecked(autoSave);
        etUserName.setText(userName);
        etPassword.setText(password);
    }
}
