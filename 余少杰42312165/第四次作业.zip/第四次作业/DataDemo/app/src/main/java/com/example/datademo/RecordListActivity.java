package com.example.datademo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecordListActivity extends AppCompatActivity implements RecordAdapter.OnItemClickListener {
    private RecyclerView recyclerView;
    private RecordAdapter adapter;
    private MyDbHelper dbHelper;
    private List<Record> records;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_list);

        setTitle("记录列表");

        dbHelper = new MyDbHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadRecords();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRecords();
    }

    private void loadRecords() {
        records = dbHelper.getAllRecords();
        adapter = new RecordAdapter(records, this);
        recyclerView.setAdapter(adapter);

        if (records.isEmpty()) {
            Toast.makeText(this, "暂无记录", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemClick(Record record) {
        Intent intent = new Intent(this, RecordDetailActivity.class);
        intent.putExtra("record_id", record.getId());
        startActivity(intent);
    }

    @Override
    public void onItemLongClick(Record record, int position) {
        new AlertDialog.Builder(this)
                .setTitle("删除记录")
                .setMessage("确定要删除这条记录吗？")
                .setPositiveButton("删除", (dialog, which) -> {
                    dbHelper.deleteRecord(record.getId());
                    records.remove(position);
                    adapter.notifyItemRemoved(position);
                    Toast.makeText(this, "删除成功", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("取消", null)
                .show();
    }
}
