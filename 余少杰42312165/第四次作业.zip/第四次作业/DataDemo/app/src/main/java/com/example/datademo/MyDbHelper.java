package com.example.datademo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MyDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "myapp.db";
    private static final int DB_VERSION = 1;

    public MyDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE records (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT," +
                "content TEXT," +
                "time TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS records");
        onCreate(db);
    }

    public long insertRecord(String title, String content) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);
        values.put("time", getCurrentTime());
        long id = db.insert("records", null, values);
        db.close();
        return id;
    }

    public List<Record> getAllRecords() {
        List<Record> records = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("records", null, null, null, null, null, "time DESC");

        while (cursor.moveToNext()) {
            Record record = new Record();
            record.setId(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
            record.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
            record.setContent(cursor.getString(cursor.getColumnIndexOrThrow("content")));
            record.setTime(cursor.getString(cursor.getColumnIndexOrThrow("time")));
            records.add(record);
        }
        cursor.close();
        db.close();
        return records;
    }

    public Record getRecordById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query("records", null, "_id = ?",
                new String[]{String.valueOf(id)}, null, null, null);

        Record record = null;
        if (cursor.moveToFirst()) {
            record = new Record();
            record.setId(cursor.getInt(cursor.getColumnIndexOrThrow("_id")));
            record.setTitle(cursor.getString(cursor.getColumnIndexOrThrow("title")));
            record.setContent(cursor.getString(cursor.getColumnIndexOrThrow("content")));
            record.setTime(cursor.getString(cursor.getColumnIndexOrThrow("time")));
        }
        cursor.close();
        db.close();
        return record;
    }

    public int deleteRecord(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete("records", "_id = ?", new String[]{String.valueOf(id)});
        db.close();
        return rows;
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
    }
}
