package com.example.datademo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RecordDetailActivity extends AppCompatActivity {
    private TextView tvTitle, tvContent, tvTime;
    private Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_detail);

        setTitle("记录详情");

        tvTitle = findViewById(R.id.tvTitle);
        tvContent = findViewById(R.id.tvContent);
        tvTime = findViewById(R.id.tvTime);
        btnBack = findViewById(R.id.btnBack);

        int recordId = getIntent().getIntExtra("record_id", -1);
        if (recordId != -1) {
            MyDbHelper dbHelper = new MyDbHelper(this);
            Record record = dbHelper.getRecordById(recordId);
            if (record != null) {
                tvTitle.setText(record.getTitle());
                tvContent.setText(record.getContent());
                tvTime.setText("时间: " + record.getTime());
            }
        }

        btnBack.setOnClickListener(v -> finish());
    }
}
