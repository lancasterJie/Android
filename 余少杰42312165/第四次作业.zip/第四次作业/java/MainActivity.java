package com.example.datademo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    private EditText etContent;
    private Button btnSave, btnLoad, btnSaveRecord;
    private MyDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new MyDbHelper(this);

        etContent = findViewById(R.id.etContent);
        btnSave = findViewById(R.id.btnSave);
        btnLoad = findViewById(R.id.btnLoad);
        btnSaveRecord = findViewById(R.id.btnSaveRecord);

        // 保存到文件
        btnSave.setOnClickListener(v -> {
            String content = etContent.getText().toString();
            if (!content.isEmpty()) {
                saveToFile(content);
            } else {
                Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show();
            }
        });

        // 从文件加载
        btnLoad.setOnClickListener(v -> {
            String content = loadFromFile();
            if (!content.isEmpty()) {
                etContent.setText(content);
                Toast.makeText(this, "加载成功", Toast.LENGTH_SHORT).show();
            }
        });

        // 保存为数据库记录
        btnSaveRecord.setOnClickListener(v -> {
            String content = etContent.getText().toString();
            if (!content.isEmpty()) {
                String title = content.length() > 20 ? content.substring(0, 20) + "..." : content;
                long id = insertRecord(title, content);
                if (id > 0) {
                    Toast.makeText(this, "记录保存成功", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 读取设置中的用户名显示在标题
        SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);
        String userName = sp.getString("user_name", "访客");
        setTitle("记事本 - " + userName);

        // 检查是否需要自动加载
        boolean autoSave = sp.getBoolean("auto_save", false);
        if (autoSave) {
            String content = loadFromFile();
            if (!content.isEmpty()) {
                etContent.setText(content);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 如果开启自动保存，退出时保存内容
        SharedPreferences sp = getSharedPreferences("settings", MODE_PRIVATE);
        boolean autoSave = sp.getBoolean("auto_save", false);
        if (autoSave) {
            String content = etContent.getText().toString();
            if (!content.isEmpty()) {
                saveToFile(content);
            }
        }
    }

    // 保存到文件
    private void saveToFile(String content) {
        try {
            FileOutputStream fos = openFileOutput("note.txt", MODE_PRIVATE);
            fos.write(content.getBytes());
            fos.close();
            Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "保存失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // 从文件加载
    private String loadFromFile() {
        try {
            FileInputStream fis = openFileInput("note.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            fis.close();
            return sb.toString().trim();
        } catch (FileNotFoundException e) {
            Toast.makeText(this, "文件不存在", Toast.LENGTH_SHORT).show();
            return "";
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    // 插入数据库记录
    private long insertRecord(String title, String content) {
        return dbHelper.insertRecord(title, content);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        } else if (id == R.id.action_records) {
            startActivity(new Intent(this, RecordListActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
