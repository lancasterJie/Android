# Activity Navigator - Android Activity 跳转课程作业

## 项目简介

这是一个演示Android Activity跳转功能的应用程序，实现了三种常见的Activity跳转方式：
- **显式跳转（Explicit Intent）**
- **隐式跳转（Implicit Intent）**
- **带返回结果的跳转（Start Activity for Result）**

## 功能特性

### 1. 显式跳转
从 `MainActivity` 直接跳转到指定的 `SecondActivity`。

**实现方式：**
```java
Intent intent = new Intent(MainActivity.this, SecondActivity.class);
startActivity(intent);
```

### 2. 隐式跳转
通过定义Action和Category，从 `SecondActivity` 隐式启动 `ThirdActivity`。

**实现方式：**
```java
Intent intent = new Intent();
intent.setAction("com.example.action.VIEW_THIRD_ACTIVITY");
intent.addCategory(Intent.CATEGORY_DEFAULT);
startActivity(intent);
```

**AndroidManifest.xml 配置：**
```xml
<activity android:name=".ThirdActivity" android:exported="true">
    <intent-filter>
        <action android:name="com.example.action.VIEW_THIRD_ACTIVITY" />
        <category android:name="android.intent.category.DEFAULT" />
    </intent-filter>
</activity>
```

### 3. 带返回结果的跳转
从 `MainActivity` 启动 `ThirdActivity`，并接收用户输入的结果返回。

**实现方式：**
```java
// 启动Activity
Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
startActivityForResult(intent, REQUEST_CODE_THIRD_ACTIVITY);

// 接收返回结果
@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == REQUEST_CODE_THIRD_ACTIVITY) {
        if (resultCode == RESULT_OK && data != null) {
            String result = data.getStringExtra("result_data");
            tvResult.setText(result);
        } else if (resultCode == RESULT_CANCELED) {
            tvResult.setText("用户取消了操作");
        }
    }
}

// 返回结果
Intent intent = new Intent();
intent.putExtra("result_data", resultText);
setResult(RESULT_OK, intent);
finish();
```

### 加分项功能

1. **长按监听器**：在 `MainActivity` 中为"启动带结果的跳转"按钮添加了长按监听，弹出Toast提示。

2. **取消操作处理**：在 `ThirdActivity` 中添加了"返回取消"按钮，演示如何处理取消操作。

## 应用结构

### Activity 组成

1. **MainActivity（主界面）**
   - 应用的入口和启动点
   - 包含跳转到SecondActivity的按钮
   - 包含启动带结果跳转的按钮（支持长按）
   - 显示从ThirdActivity返回的结果

2. **SecondActivity（中间页面）**
   - 显示第二个Activity的界面
   - 包含返回主页的按钮
   - 包含隐式跳转的按钮

3. **ThirdActivity（结果页面）**
   - 提供输入框让用户输入文本
   - 包含返回结果的按钮
   - 包含返回取消的按钮

## 应用流程图

```mermaid
graph LR
    A[MainActivity] -->|显式Intent| B[SecondActivity]
    B -->|finish| A
    B -->|隐式Intent| C[ThirdActivity]
    A -->|startActivityForResult| C
    C -->|setResult + finish| A
    
    style A fill:#E3F2FD
    style B fill:#E8F5E9
    style C fill:#FFF3E0
```

## 项目文件结构

```
app/src/main/
├── java/com/example/experiment/
│   ├── MainActivity.java          # 主Activity
│   ├── SecondActivity.java        # 第二个Activity
│   └── ThirdActivity.java         # 第三个Activity
├── res/
│   └── layout/
│       ├── activity_main.xml      # 主界面布局
│       ├── activity_second.xml    # 第二个Activity布局
│       └── activity_third.xml     # 第三个Activity布局
└── AndroidManifest.xml            # 应用配置文件
```

## 技术要点

### 1. Intent 的使用
- 显式Intent：直接指定目标Activity类
- 隐式Intent：通过Action和Category匹配目标Activity

### 2. Activity 生命周期
- `onCreate()`: 初始化视图和设置事件监听
- `onActivityResult()`: 接收子Activity返回的结果
- `finish()`: 结束当前Activity并返回

### 3. 数据传递
- 使用 `Intent.putExtra()` 传递数据
- 使用 `Intent.getStringExtra()` 接收数据
- 使用 `setResult()` 设置返回结果

### 4. AndroidManifest 配置
- 注册所有Activity
- 为支持隐式跳转的Activity配置intent-filter
- 正确设置exported属性

## 运行要求

- Android SDK 版本：最低支持 API 21 (Android 5.0)
- 开发工具：Android Studio
- 构建工具：Gradle

## 使用说明

1. **启动应用**：进入MainActivity主界面
2. **显式跳转测试**：
   - 点击"跳转到 SecondActivity"按钮
   - 进入SecondActivity后，可以点击"返回到主页"返回
3. **隐式跳转测试**：
   - 在SecondActivity中点击"隐式跳转"按钮
   - 自动启动ThirdActivity
4. **带结果跳转测试**：
   - 在MainActivity点击"启动带结果的跳转"按钮
   - 在ThirdActivity中输入文本
   - 点击"返回结果"按钮
   - MainActivity会显示返回的文本内容
5. **长按功能测试**：
   - 长按"启动带结果的跳转"按钮
   - 会弹出Toast提示
6. **取消操作测试**：
   - 在ThirdActivity点击"返回取消"按钮
   - MainActivity会显示"用户取消了操作"

## 作业完成情况

✅ 实现显式跳转（Explicit Intent）  
✅ 实现隐式跳转（Implicit Intent）  
✅ 实现带返回结果的跳转（Start Activity for Result）  
✅ 加分项：长按监听器  
✅ 加分项：取消操作处理  
✅ 代码清晰、有注释、遵循良好编码规范  
✅ 提供完整的README文档说明

## 学习总结

通过本次作业，掌握了以下知识点：

1. **Intent的两种使用方式**：理解显式Intent和隐式Intent的区别和使用场景
2. **Activity间的数据传递**：学会使用Intent传递和接收数据
3. **Activity的返回机制**：掌握startActivityForResult和onActivityResult的使用
4. **AndroidManifest配置**：了解如何在Manifest中注册Activity和配置intent-filter
5. **事件监听器**：实现点击和长按监听器

## 作者信息

- 课程：Android Activity 跳转课程作业
- 项目名称：Activity Navigator
- 完成时间：2025年10月

