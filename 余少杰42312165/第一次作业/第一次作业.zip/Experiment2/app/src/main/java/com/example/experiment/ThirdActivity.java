package com.example.experiment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ThirdActivity extends AppCompatActivity {

    private EditText etResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        // 初始化视图
        etResult = findViewById(R.id.etResult);
        Button btnReturnResult = findViewById(R.id.btnReturnResult);
        Button btnReturnCancel = findViewById(R.id.btnReturnCancel);

        // 返回结果
        btnReturnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String resultText = etResult.getText().toString();
                Intent intent = new Intent();
                intent.putExtra("result_data", resultText);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        // 返回取消（加分项）
        btnReturnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });
    }
}

