# Android Activity 生命周期观察实验

## 实验目的

1. 掌握 Android Activity 生命周期的基本概念
2. 通过 Log 观察 Activity 在不同场景下的生命周期变化
3. 理解 Activity 跳转和返回时的生命周期调用顺序
4. 分析普通 Activity 与 Dialog Activity 在生命周期上的差异

## 实验要求

### 基础任务

1. **创建主 Activity**
   - 创建 MainActivity，重写所有生命周期方法
   - 在每个生命周期方法中添加 Log 输出，格式：`Log.d("Lifecycle", "MainActivity - onCreate")`

2. **创建普通 SecondActivity**
   - 创建第二个普通 Activity
   - 同样重写所有生命周期方法并添加 Log 输出

3. **创建 Dialog Activity**
   - 创建第三个 Activity，设置为对话框样式
   - 重写所有生命周期方法并添加 Log 输出

## 项目结构

### Activity 组成

1. **MainActivity（主界面）**
   - 应用的入口和启动点
   - 包含跳转到SecondActivity的按钮
   - 包含跳转到DialogActivity的按钮

2. **SecondActivity（普通页面）**
   - 全屏显示的普通Activity
   - 包含返回主页的按钮
   - 包含跳转到DialogActivity的按钮

3. **DialogActivity（对话框页面）**
   - 对话框样式的Activity
   - 后面的Activity仍然可见
   - 包含关闭按钮

## 生命周期方法

Activity 的主要生命周期方法：

| 方法 | 说明 | 调用时机 |
|------|------|----------|
| `onCreate()` | 创建 | Activity 首次创建时调用 |
| `onStart()` | 启动 | Activity 即将可见时调用 |
| `onResume()` | 恢复 | Activity 获得焦点，可与用户交互 |
| `onPause()` | 暂停 | Activity 失去焦点，但仍然可见 |
| `onStop()` | 停止 | Activity 完全不可见 |
| `onDestroy()` | 销毁 | Activity 被销毁前调用 |
| `onRestart()` | 重启 | Activity 从停止状态重新启动 |

## 实验步骤

### 第一部分：基础生命周期观察

#### 1. 启动应用观察

启动应用，观察 MainActivity 的生命周期调用顺序：

**预期输出：**
```
MainActivity - onCreate
MainActivity - onStart
MainActivity - onResume
```

#### 2. 普通 Activity 跳转

从 MainActivity 跳转到 SecondActivity，观察两个 Activity 的生命周期变化：

**预期输出：**
```
MainActivity - onPause
SecondActivity - onCreate
SecondActivity - onStart
SecondActivity - onResume
MainActivity - onStop
```

#### 3. SecondActivity 返回

从 SecondActivity 返回 MainActivity，再次观察生命周期变化：

**预期输出：**
```
SecondActivity - onPause
MainActivity - onRestart
MainActivity - onStart
MainActivity - onResume
SecondActivity - onStop
SecondActivity - onDestroy
```

### 第二部分：Dialog Activity 跳转观察

#### 1. 跳转到 Dialog Activity

从 MainActivity 跳转到 DialogActivity，观察生命周期变化：

**预期输出：**
```
MainActivity - onPause
DialogActivity - onCreate
DialogActivity - onStart
DialogActivity - onResume
```

**关键观察点：** MainActivity 只调用了 `onPause()`，没有调用 `onStop()`，因为 MainActivity 仍然部分可见。

#### 2. Dialog Activity 返回

从 DialogActivity 返回，观察生命周期变化：

**预期输出：**
```
DialogActivity - onPause
DialogActivity - onStop
DialogActivity - onDestroy
MainActivity - onResume
```

**关键观察点：** MainActivity 只调用了 `onResume()`，没有调用 `onRestart()` 和 `onStart()`，因为 MainActivity 从未完全停止。

## 第二部分：数据记录与分析

### 生命周期对比表

| 场景 | MainActivity 生命周期顺序 | 目标Activity 生命周期顺序 |
|------|-------------------------|------------------------|
| 应用启动 | onCreate → onStart → onResume | - |
| Main → SecondActivity | onPause → onStop | onCreate → onStart → onResume |
| SecondActivity 返回 | onRestart → onStart → onResume | onPause → onStop → onDestroy |
| Main → Dialog Activity | onPause | onCreate → onStart → onResume |
| Dialog Activity 返回 | onResume | onPause → onStop → onDestroy |

### 关键发现

1. **普通Activity跳转**：
   - 旧Activity会完全停止（onPause → onStop）
   - 新Activity完全覆盖旧Activity

2. **Dialog Activity跳转**：
   - 旧Activity只暂停（onPause），不停止
   - 旧Activity仍然部分可见
   - 返回时只需恢复（onResume），不需要重启

3. **生命周期调用顺序**：
   - 跳转时：旧Activity先暂停，新Activity再启动
   - 返回时：新Activity先销毁，旧Activity再恢复

## 应用流程图

### 普通Activity跳转流程

```mermaid
sequenceDiagram
    participant M as MainActivity
    participant S as SecondActivity
    
    Note over M: onCreate → onStart → onResume
    M->>S: startActivity()
    Note over M: onPause
    Note over S: onCreate → onStart → onResume
    Note over M: onStop
    
    S->>M: finish()
    Note over S: onPause
    Note over M: onRestart → onStart → onResume
    Note over S: onStop → onDestroy
```

### Dialog Activity跳转流程

```mermaid
sequenceDiagram
    participant M as MainActivity
    participant D as DialogActivity
    
    Note over M: onCreate → onStart → onResume
    M->>D: startActivity()
    Note over M: onPause
    Note over D: onCreate → onStart → onResume
    Note over M: 仍然可见（未onStop）
    
    D->>M: finish()
    Note over D: onPause → onStop → onDestroy
    Note over M: onResume
```

## 技术实现要点

### 1. 生命周期方法重写

所有Activity都重写了7个主要生命周期方法：

```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Log.d("Lifecycle", "MainActivity - onCreate");
    setContentView(R.layout.activity_main);
}

@Override
protected void onStart() {
    super.onStart();
    Log.d("Lifecycle", "MainActivity - onStart");
}

@Override
protected void onResume() {
    super.onResume();
    Log.d("Lifecycle", "MainActivity - onResume");
}

@Override
protected void onPause() {
    super.onPause();
    Log.d("Lifecycle", "MainActivity - onPause");
}

@Override
protected void onStop() {
    super.onStop();
    Log.d("Lifecycle", "MainActivity - onStop");
}

@Override
protected void onDestroy() {
    super.onDestroy();
    Log.d("Lifecycle", "MainActivity - onDestroy");
}

@Override
protected void onRestart() {
    super.onRestart();
    Log.d("Lifecycle", "MainActivity - onRestart");
}
```

### 2. Dialog Activity 配置

在 AndroidManifest.xml 中设置对话框主题：

```xml
<activity
    android:name=".DialogActivity"
    android:exported="false"
    android:theme="@style/Theme.AppCompat.Dialog" />
```

### 3. Log 输出格式

统一使用 "Lifecycle" 作为 Tag，便于在 Logcat 中过滤：

```java
private static final String TAG = "Lifecycle";
Log.d(TAG, "MainActivity - onCreate");
```

## 使用说明

### 运行实验

1. **打开 Logcat**：在 Android Studio 中打开 Logcat 窗口
2. **设置过滤器**：在 Logcat 中设置过滤器为 "Lifecycle"
3. **启动应用**：运行应用并观察启动时的生命周期
4. **测试跳转**：
   - 点击"跳转到 SecondActivity"，观察普通Activity跳转
   - 点击返回键，观察返回时的生命周期
   - 点击"跳转到 Dialog Activity"，观察对话框跳转
   - 点击关闭，观察对话框返回的生命周期

### 观察要点

1. **启动顺序**：onCreate → onStart → onResume
2. **跳转顺序**：旧Activity.onPause → 新Activity启动 → 旧Activity.onStop
3. **返回顺序**：旧Activity.onPause → 前Activity恢复 → 旧Activity销毁
4. **Dialog特殊性**：后台Activity不调用onStop

## 实验结论

### Activity 生命周期规律

1. **创建到运行**：onCreate → onStart → onResume
2. **暂停到停止**：onPause → onStop
3. **重新启动**：onRestart → onStart → onResume
4. **销毁**：onPause → onStop → onDestroy

### 普通Activity vs Dialog Activity

| 特性 | 普通Activity | Dialog Activity |
|------|------------|----------------|
| 是否覆盖后台Activity | 完全覆盖 | 部分覆盖 |
| 后台Activity状态 | onStop (停止) | onPause (暂停) |
| 返回时恢复流程 | onRestart → onStart → onResume | 仅 onResume |
| 用户体验 | 完全切换 | 对话框效果 |

### 关键发现

1. Activity的生命周期是成对出现的：
   - onCreate ↔ onDestroy
   - onStart ↔ onStop
   - onResume ↔ onPause

2. 生命周期调用有严格的顺序，理解这个顺序对于：
   - 正确保存和恢复数据
   - 避免内存泄漏
   - 优化应用性能
   非常重要

3. Dialog Activity的特殊性使得它适合：
   - 需要保持后台Activity可见的场景
   - 轻量级的用户交互
   - 快速切换的场景

## 项目文件

- **Java源文件**：`app/src/main/java/com/example/experiment/`
  - MainActivity.java
  - SecondActivity.java
  - DialogActivity.java
- **布局文件**：`app/src/main/res/layout/`
  - activity_main.xml
  - activity_second.xml
  - activity_dialog.xml
- **配置文件**：`app/src/main/AndroidManifest.xml`

## 实验完成情况

✅ 创建 MainActivity 并重写所有生命周期方法  
✅ 创建 SecondActivity 并重写所有生命周期方法  
✅ 创建 DialogActivity 并设置对话框主题  
✅ 在所有生命周期方法中添加 Log 输出  
✅ 观察普通 Activity 跳转的生命周期  
✅ 观察 Dialog Activity 跳转的生命周期  
✅ 分析并记录生命周期差异  
✅ 提供完整的实验报告和说明文档

## 学习总结

通过本次实验，我们深入理解了：

1. **Activity生命周期的完整流程**：从创建到销毁的整个过程
2. **生命周期方法的调用时机**：什么时候调用哪些方法
3. **Activity间的交互**：跳转和返回时的生命周期变化
4. **不同类型Activity的差异**：普通Activity与Dialog Activity的区别
5. **实际应用价值**：如何利用生命周期优化应用性能

这些知识对于开发高质量的Android应用至关重要。

## 作者信息

- 课程：Android Activity 生命周期观察实验
- 项目名称：Activity Lifecycle Observer
- 完成时间：2025年10月
