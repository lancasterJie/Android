# Fragment 实验报告

## 学生信息
- **姓名**: 余少杰
- **学号**: 42312165
- **实验日期**: 2025年

---

## 一、实验目的

1. 掌握 Fragment 的基本使用方法
2. 学会使用 RadioGroup 控制 Fragment 切换
3. 理解 Bundle 在不同组件间传递数据的方式
4. 掌握 onSaveInstanceState 保存和恢复状态的机制

---

## 二、实验内容

### 2.1 RadioGroup 控制 Fragment 切换

#### 功能描述
创建包含 4 个 RadioButton 的 RadioGroup，每个 RadioButton 对应一个不同的 Fragment，点击时切换到对应的 Fragment。

#### 核心代码

**MainActivity.java**
```java
public class MainActivity extends AppCompatActivity {
    private RadioGroup radioGroup;
    private FragmentManager fragmentManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        fragmentManager = getSupportFragmentManager();
        radioGroup = findViewById(R.id.radioGroup);
        
        // 默认显示第一个Fragment
        if (savedInstanceState == null) {
            switchFragment(new Fragment1());
        }
        
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            Fragment fragment = null;
            if (checkedId == R.id.rb1) {
                fragment = new Fragment1();
            } else if (checkedId == R.id.rb2) {
                fragment = new Fragment2();
            } else if (checkedId == R.id.rb3) {
                fragment = new Fragment3();
            } else if (checkedId == R.id.rb4) {
                fragment = new Fragment4();
            }
            if (fragment != null) {
                switchFragment(fragment);
            }
        });
    }
    
    private void switchFragment(Fragment fragment) {
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
```

**activity_main.xml**
```xml
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical">

    <FrameLayout
        android:id="@+id/fragment_container"
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1" />

    <RadioGroup
        android:id="@+id/radioGroup"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:gravity="center">

        <RadioButton
            android:id="@+id/rb1"
            style="@style/RadioButtonStyle"
            android:text="首页" />

        <RadioButton
            android:id="@+id/rb2"
            style="@style/RadioButtonStyle"
            android:text="消息" />

        <RadioButton
            android:id="@+id/rb3"
            style="@style/RadioButtonStyle"
            android:text="发现" />

        <RadioButton
            android:id="@+id/rb4"
            style="@style/RadioButtonStyle"
            android:text="我的" />
    </RadioGroup>
</LinearLayout>
```

**res/drawable/radio_button_selector.xml**
```xml
<?xml version="1.0" encoding="utf-8"?>
<selector xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:state_checked="true" android:drawable="@color/purple_500" />
    <item android:state_checked="false" android:drawable="@color/gray" />
</selector>
```

**res/values/styles.xml**
```xml
<style name="RadioButtonStyle">
    <item name="android:layout_width">0dp</item>
    <item name="android:layout_height">wrap_content</item>
    <item name="android:layout_weight">1</item>
    <item name="android:button">@null</item>
    <item name="android:gravity">center</item>
    <item name="android:padding">16dp</item>
    <item name="android:background">@drawable/radio_button_selector</item>
</style>
```

---

### 2.2 Bundle 数据传输

#### 场景 A: Activity → Activity

**MainActivity 传递数据**
```java
Intent intent = new Intent(this, DetailActivity.class);
Bundle bundle = new Bundle();
bundle.putString("user_name", "余少杰");
bundle.putInt("age", 20);
bundle.putBoolean("is_student", true);
intent.putExtras(bundle);
startActivity(intent);
```

**DetailActivity 接收数据**
```java
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_detail);
    
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
        String userName = bundle.getString("user_name");
        int age = bundle.getInt("age");
        boolean isStudent = bundle.getBoolean("is_student");
        
        TextView tvInfo = findViewById(R.id.tv_info);
        tvInfo.setText(String.format("姓名: %s\n年龄: %d\n是否学生: %s", 
                userName, age, isStudent ? "是" : "否"));
    }
}
```

#### 场景 B: Activity ↔ Fragment

**Activity 向 Fragment 传递数据**
```java
Fragment1 fragment = new Fragment1();
Bundle args = new Bundle();
args.putString("init_data", "来自Activity的初始数据");
fragment.setArguments(args);
```

**Fragment 接收数据**
```java
@Override
public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (getArguments() != null) {
        String initData = getArguments().getString("init_data");
    }
}
```

**Fragment 向 Activity 返回数据（通过接口）**
```java
// 定义接口
public interface OnFragmentResultListener {
    void onResult(String result);
}

// Fragment中调用
if (getActivity() instanceof OnFragmentResultListener) {
    ((OnFragmentResultListener) getActivity()).onResult("处理结果");
}
```

#### 场景 C: Fragment → Fragment（通过 Activity 中转）

```java
// Fragment1 发送数据
((MainActivity) getActivity()).transferData("来自Fragment1的数据");

// MainActivity 中转
public void transferData(String data) {
    Fragment2 fragment2 = (Fragment2) getSupportFragmentManager()
            .findFragmentByTag("fragment2");
    if (fragment2 != null) {
        fragment2.receiveData(data);
    }
}

// Fragment2 接收
public void receiveData(String data) {
    tvReceived.setText(data);
}
```

---

### 2.3 屏幕旋转与状态保存

#### 生命周期观察

`onSaveInstanceState` 在 `onPause()` 之后、`onStop()` 之前被调用。

```
onPause() → onSaveInstanceState() → onStop() → onDestroy()
```

#### 状态保存与恢复代码

```java
public class MainActivity extends AppCompatActivity {
    private static final String KEY_EDIT_TEXT = "edit_text_content";
    private EditText editText;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
        
        // 恢复状态
        if (savedInstanceState != null) {
            String savedText = savedInstanceState.getString(KEY_EDIT_TEXT, "");
            textView.setText("恢复的内容: " + savedText);
            Log.d("Lifecycle", "onCreate - 恢复数据: " + savedText);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        String content = editText.getText().toString();
        outState.putString(KEY_EDIT_TEXT, content);
        Log.d("Lifecycle", "onSaveInstanceState - 保存数据: " + content);
    }
}
```

#### Log 输出示例

```
D/Lifecycle: onPause
D/Lifecycle: onSaveInstanceState - 保存数据: 测试内容
D/Lifecycle: onStop
D/Lifecycle: onDestroy
D/Lifecycle: onCreate - 恢复数据: 测试内容
D/Lifecycle: onStart
D/Lifecycle: onResume
```

---

## 三、运行截图

### 3.1 RadioGroup 切换 Fragment

| Fragment1 (首页) | Fragment2 (消息) |
|:---:|:---:|
| ![首页Fragment](screenshots/3ba19dba89581f566893b77e93608295.jpg) | ![消息Fragment](screenshots/89deec0503305050a4799fa258000db1.jpg) |

| Fragment3 (发现) | Fragment4 (我的) |
|:---:|:---:|
| ![发现Fragment](screenshots/96fcf44d8500428bcde2e7f2471a28d8.jpg) | ![我的Fragment](screenshots/e90c620adef266573e7eb86d2b736783.jpg) |

### 3.2 Bundle 数据传输

各 Fragment 成功接收并显示来自 Activity 的数据：
- **首页 Fragment**: 接收到数据 "欢迎来到首页"
- **消息 Fragment**: 接收到数据 "这是消息页面"
- **发现 Fragment**: 接收到数据 "发现新内容"
- **我的 Fragment**: 显示用户名 "余少杰"，学号 "42312165"

### 3.3 屏幕旋转状态保存

![状态恢复](screenshots/edfffea51eb0bfe46776b1a1f521a463.jpg)

- 旋转前输入内容: "ysj是猪"
- 旋转后成功恢复: "恢复的内容: ysj是猪"

---

## 四、实验总结

1. **Fragment 切换**: 使用 FragmentManager 的 replace() 方法配合 RadioGroup 实现底部导航效果
2. **Bundle 传输**: Bundle 是 Android 中组件间传递数据的标准方式，支持多种数据类型
3. **状态保存**: onSaveInstanceState 在配置更改（如屏幕旋转）时保存临时数据，需要在 onCreate 中恢复

---

## 五、完整项目结构

```
app/
├── src/main/java/com/example/fragmentdemo/
│   ├── MainActivity.java
│   ├── DetailActivity.java
│   ├── Fragment1.java
│   ├── Fragment2.java
│   ├── Fragment3.java
│   └── Fragment4.java
├── src/main/res/layout/
│   ├── activity_main.xml
│   ├── activity_detail.xml
│   ├── fragment_1.xml
│   ├── fragment_2.xml
│   ├── fragment_3.xml
│   └── fragment_4.xml
└── src/main/res/drawable/
    └── radio_button_selector.xml
```
