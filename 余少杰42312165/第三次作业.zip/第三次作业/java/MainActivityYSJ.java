package com.example.fragmentdemo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity implements OnFragmentResultListener {
    private static final String TAG = "Lifecycle";
    private static final String KEY_EDIT_TEXT = "edit_text_content";
    
    private RadioGroup radioGroup;
    private FragmentManager fragmentManager;
    private EditText editText;
    private TextView textView;
    private TextView tvFragmentResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "MainActivity - onCreate");
        setContentView(R.layout.activity_main);

        fragmentManager = getSupportFragmentManager();
        radioGroup = findViewById(R.id.radioGroup);
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
        tvFragmentResult = findViewById(R.id.tvFragmentResult);

        // 恢复状态
        if (savedInstanceState != null) {
            String savedText = savedInstanceState.getString(KEY_EDIT_TEXT, "");
            textView.setText("恢复的内容: " + savedText);
            Log.d(TAG, "onCreate - 恢复数据: " + savedText);
        } else {
            // 默认显示第一个Fragment
            switchFragment(createFragmentWithArgs(new Fragment1(), "欢迎来到首页"));
        }

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            Fragment fragment = null;
            String initData = "";
            
            if (checkedId == R.id.rb1) {
                fragment = new Fragment1();
                initData = "欢迎来到首页";
            } else if (checkedId == R.id.rb2) {
                fragment = new Fragment2();
                initData = "这是消息页面";
            } else if (checkedId == R.id.rb3) {
                fragment = new Fragment3();
                initData = "发现新内容";
            } else if (checkedId == R.id.rb4) {
                fragment = new Fragment4();
                initData = "个人中心";
            }
            
            if (fragment != null) {
                switchFragment(createFragmentWithArgs(fragment, initData));
            }
        });

        // 跳转到DetailActivity按钮
        findViewById(R.id.btnToDetail).setOnClickListener(v -> {
            Intent intent = new Intent(this, DetailActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString("user_name", "余少杰");
            bundle.putInt("age", 20);
            bundle.putBoolean("is_student", true);
            intent.putExtras(bundle);
            startActivity(intent);
        });
    }

    private Fragment createFragmentWithArgs(Fragment fragment, String initData) {
        Bundle args = new Bundle();
        args.putString("init_data", initData);
        fragment.setArguments(args);
        return fragment;
    }

    private void switchFragment(Fragment fragment) {
        fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    // Fragment间数据中转
    public void transferData(String data) {
        Fragment2 fragment2 = (Fragment2) fragmentManager.findFragmentByTag("fragment2");
        if (fragment2 != null) {
            fragment2.receiveData(data);
        }
    }

    // 接收Fragment返回的结果
    @Override
    public void onResult(String result) {
        tvFragmentResult.setText("Fragment返回: " + result);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (editText != null) {
            String content = editText.getText().toString();
            outState.putString(KEY_EDIT_TEXT, content);
            Log.d(TAG, "onSaveInstanceState - 保存数据: " + content);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "MainActivity - onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity - onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "MainActivity - onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "MainActivity - onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity - onDestroy");
    }
}
