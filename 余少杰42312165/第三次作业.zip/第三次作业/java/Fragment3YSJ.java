package com.example.fragmentdemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment3 extends Fragment {
    private String initData;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            initData = getArguments().getString("init_data", "默认数据");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_3, container, false);
        
        TextView tvTitle = view.findViewById(R.id.tvTitle);
        tvTitle.setText("发现 Fragment");
        
        TextView tvInitData = view.findViewById(R.id.tvInitData);
        tvInitData.setText("接收到的数据: " + initData);
        
        Button btnTransfer = view.findViewById(R.id.btnTransfer);
        btnTransfer.setOnClickListener(v -> {
            // 通过Activity中转数据到Fragment2
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).transferData("来自Fragment3的数据");
            }
        });
        
        return view;
    }
}
