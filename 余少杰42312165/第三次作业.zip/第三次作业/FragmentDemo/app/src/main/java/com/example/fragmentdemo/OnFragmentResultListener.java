package com.example.fragmentdemo;

public interface OnFragmentResultListener {
    void onResult(String result);
}
