package com.example.fragmentdemo;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String userName = bundle.getString("user_name", "");
            int age = bundle.getInt("age", 0);
            boolean isStudent = bundle.getBoolean("is_student", false);

            TextView tvInfo = findViewById(R.id.tv_info);
            tvInfo.setText(String.format("姓名: %s\n年龄: %d\n是否学生: %s",
                    userName, age, isStudent ? "是" : "否"));
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}
