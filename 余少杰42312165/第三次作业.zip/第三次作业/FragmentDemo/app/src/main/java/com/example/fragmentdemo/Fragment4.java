package com.example.fragmentdemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Fragment4 extends Fragment {
    private String initData;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            initData = getArguments().getString("init_data", "默认数据");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_4, container, false);
        
        TextView tvTitle = view.findViewById(R.id.tvTitle);
        tvTitle.setText("我的 Fragment");
        
        TextView tvInitData = view.findViewById(R.id.tvInitData);
        tvInitData.setText("接收到的数据: " + initData);
        
        TextView tvUserInfo = view.findViewById(R.id.tvUserInfo);
        tvUserInfo.setText("用户名: 余少杰\n学号: 42312165");
        
        return view;
    }
}
