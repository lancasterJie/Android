package com.example.myapplication;

/**
 * 待办事项数据模型类
 * 包含任务名称和截止日期两个属性
 */
public class TaskItemYSJ {
    private String taskName;  // 任务名称
    private String dueDate;   // 截止日期

    // 构造方法
    public TaskItemYSJ(String taskName, String dueDate) {
        this.taskName = taskName;
        this.dueDate = dueDate;
    }

    // Getter 方法
    public String getTaskName() {
        return taskName;
    }

    public String getDueDate() {
        return dueDate;
    }

    // Setter 方法
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }
}
