package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

/**
 * 自定义任务列表适配器
 * 继承 ArrayAdapter，用于将 TaskItemYSJ 数据绑定到 ListView 列表项
 */
public class TaskAdapterYSJ extends ArrayAdapter<TaskItemYSJ> {
    private Context context;
    private List<TaskItemYSJ> taskList;

    public TaskAdapterYSJ(@NonNull Context context, @NonNull List<TaskItemYSJ> tasks) {
        super(context, R.layout.item_task_ysj, tasks);
        this.context = context;
        this.taskList = tasks;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // 复用 convertView 提高性能
        ViewHolder holder;

        if (convertView == null) {
            // 加载列表项布局
            convertView = LayoutInflater.from(context).inflate(R.layout.item_task_ysj, parent, false);

            // 创建 ViewHolder 并缓存视图引用
            holder = new ViewHolder();
            holder.tvTaskName = convertView.findViewById(R.id.tvTaskName);
            holder.tvDueDate = convertView.findViewById(R.id.tvDueDate);
            convertView.setTag(holder);
        } else {
            // 从缓存中获取 ViewHolder
            holder = (ViewHolder) convertView.getTag();
        }

        // 获取当前位置的数据
        TaskItemYSJ currentTask = taskList.get(position);

        // 将数据绑定到视图
        holder.tvTaskName.setText(currentTask.getTaskName());
        holder.tvDueDate.setText("截止日期: " + currentTask.getDueDate());

        return convertView;
    }

    /**
     * ViewHolder 模式：缓存视图引用，避免重复 findViewById
     */
    private static class ViewHolder {
        TextView tvTaskName;
        TextView tvDueDate;
    }
}
