package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

/**
 * 待办事项清单主界面
 * 使用 ListView 展示任务列表
 */
public class MainActivity extends AppCompatActivity {
    private ListView lvTasks;
    private ArrayList<TaskItemYSJ> taskList;
    private TaskAdapterYSJ adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化 ListView
        lvTasks = findViewById(R.id.lvTasks);

        // 初始化任务数据
        initTaskData();

        // 创建适配器并设置给 ListView
        adapter = new TaskAdapterYSJ(this, taskList);
        lvTasks.setAdapter(adapter);

        // 设置列表项点击事件
        lvTasks.setOnItemClickListener((parent, view, position, id) -> {
            TaskItemYSJ task = taskList.get(position);
            Toast.makeText(this, "点击了: " + task.getTaskName(), Toast.LENGTH_SHORT).show();
        });
    }

    /**
     * 初始化任务数据
     * 使用作业要求的示例数据
     */
    private void initTaskData() {
        taskList = new ArrayList<>();
        taskList.add(new TaskItemYSJ("Complete Android Homework", "2025-12-20"));
        taskList.add(new TaskItemYSJ("Buy groceries", "2024-05-01"));
        taskList.add(new TaskItemYSJ("Walk the dog", "2024-04-20"));
        taskList.add(new TaskItemYSJ("Call John", "2024-04-23"));
    }
}