package com.example.activitynavigator;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // 返回主页面按钮
        Button backBtn = findViewById(R.id.back_btn);
        backBtn.setOnClickListener(v -> finish());

        // 隐式跳转按钮
        Button implicitBtn = findViewById(R.id.implicit_btn);
        implicitBtn.setOnClickListener(v -> {
            // 创建隐式Intent
            Intent intent = new Intent();
            intent.setAction("com.example.action.VIEW_THIRD_ACTIVITY");
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            startActivity(intent);
        });
    }
}