package com.example.activitynavigator;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.annotation.Nullable;
import android.content.Intent;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;


public class MainActivity extends AppCompatActivity {
    // 请求码常量
    private static final int REQUEST_CODE = 101;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化视图
        Button explicitBtn = findViewById(R.id.explicit_btn);
        Button resultBtn = findViewById(R.id.result_btn);
        resultTextView = findViewById(R.id.result_text);

        // 显式跳转到SecondActivity
        explicitBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });

        // 带返回结果的跳转
        resultBtn.setOnClickListener(v -> startThirdActivity());

        // 长按监听器
        resultBtn.setOnLongClickListener(v -> {
            Toast.makeText(MainActivity.this, "长按启动了带返回结果的跳转！", Toast.LENGTH_SHORT).show();
            startThirdActivity();
            return true;
        });
    }

    // 启动ThirdActivity的方法
    private void startThirdActivity() {
        Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
        startActivityForResult(intent, REQUEST_CODE);
    }

    // 处理返回结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                String result = data.getStringExtra("result_data");
                resultTextView.setText("返回结果: " + result);
            } else if (resultCode == RESULT_CANCELED) {
                resultTextView.setText("操作已取消");
            }
        }
    }
}