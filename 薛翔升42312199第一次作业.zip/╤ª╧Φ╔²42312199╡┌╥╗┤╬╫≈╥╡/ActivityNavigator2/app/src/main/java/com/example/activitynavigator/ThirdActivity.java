package com.example.activitynavigator;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ThirdActivity extends AppCompatActivity {
    private EditText inputEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        // 初始化视图
        inputEditText = findViewById(R.id.input_edittext);
        Button returnBtn = findViewById(R.id.return_btn);
        Button cancelBtn = findViewById(R.id.cancel_btn);

        // 返回结果按钮
        returnBtn.setOnClickListener(v -> {
            String inputText = inputEditText.getText().toString();
            Intent intent = new Intent();
            intent.putExtra("result_data", inputText);
            setResult(RESULT_OK, intent);
            finish();
        });

        // 取消按钮
        cancelBtn.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }
}
