package com.example.fragmentdemo;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

    private FragmentCommunicationCallback callback;
    private EditText etDataToSend;

    public interface FragmentCommunicationCallback {
        void onSendDataToFragment3(String data);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof FragmentCommunicationCallback) {
            callback = (FragmentCommunicationCallback) context;
        } else {
            throw new RuntimeException(context + " must implement FragmentCommunicationCallback");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        etDataToSend = view.findViewById(R.id.etDataToSend);
        Button btnSendToFragment = view.findViewById(R.id.btnSendToFragment);

        btnSendToFragment.setOnClickListener(v -> {
            String data = etDataToSend.getText().toString();
            if (!data.isEmpty() && callback != null) {
                callback.onSendDataToFragment3(data);
            }
        });

        return view;
    }
}