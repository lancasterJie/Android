package com.example.fragmentdemo;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;  // 添加这行导入
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity implements
        FirstFragment.FragmentCallback,
        SecondFragment.FragmentCommunicationCallback {

    private RadioGroup radioGroup;
    private String fragmentDataFromActivity = "欢迎光临!";
    private String dataForFragment3 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("MainActivity", "onCreate called");

        radioGroup = findViewById(R.id.radioGroup);

        setupRadioGroup();

        // Set default fragment
        if (savedInstanceState == null) {
            switchToFragment(1);
            radioGroup.check(R.id.radioFragment1);
        }

        // Add button to test Activity to Activity communication
        addTestButton();
    }

    private void setupRadioGroup() {
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioFragment1) {
                switchToFragment(1);
            } else if (checkedId == R.id.radioFragment2) {
                switchToFragment(2);
            } else if (checkedId == R.id.radioFragment3) {
                switchToFragment(3);
            } else if (checkedId == R.id.radioFragment4) {
                switchToFragment(4);
            }
        });
    }

    private void switchToFragment(int fragmentNumber) {
        Fragment fragment = null;
        String tag = null;

        switch (fragmentNumber) {
            case 1:
                fragment = getSupportFragmentManager().findFragmentByTag("fragment1");
                if (fragment == null) {
                    fragment = FirstFragment.newInstance(fragmentDataFromActivity);
                }
                tag = "fragment1";
                break;
            case 2:
                fragment = getSupportFragmentManager().findFragmentByTag("fragment2");
                if (fragment == null) {
                    fragment = new SecondFragment();
                }
                tag = "fragment2";
                break;
            case 3:
                fragment = getSupportFragmentManager().findFragmentByTag("fragment3");
                if (fragment == null) {
                    fragment = ThirdFragment.newInstance(dataForFragment3);
                }
                tag = "fragment3";
                break;
            case 4:
                fragment = getSupportFragmentManager().findFragmentByTag("fragment4");
                if (fragment == null) {
                    fragment = new FourthFragment();
                }
                tag = "fragment4";
                Log.d("MainActivity", "切换到 Fragment 4, 使用tag: " + tag);
                break;
            default:
                fragment = FirstFragment.newInstance(fragmentDataFromActivity);
                tag = "fragment1";
        }

        if (fragment != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, fragment, tag)
                    .commit();
            Log.d("MainActivity", "Fragment 事务提交完成");
        }
    }

    private void addTestButton() {
        FrameLayout fragmentContainer = findViewById(R.id.fragmentContainer);

        Button btnTest = new Button(this);
        btnTest.setText("查看用户详情");
        btnTest.setBackgroundColor(Color.parseColor("#4CAF50"));
        btnTest.setTextColor(Color.WHITE);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.BOTTOM | Gravity.END;
        params.setMargins(0, 0, 16, 16);
        btnTest.setLayoutParams(params);

        btnTest.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailActivity.class);

            Bundle bundle = new Bundle();
            bundle.putString("user_name", "李四"); // 修改这里
            bundle.putInt("user_age", 28); // 修改这里
            bundle.putBoolean("is_student", false); // 修改这里

            intent.putExtras(bundle);
            startActivity(intent);
        });

        fragmentContainer.addView(btnTest);
    }

    // B: Fragment → Activity
    @Override
    public void onDataReceivedFromFragment(String data) {
        Toast.makeText(this, "收到信息: " + data, Toast.LENGTH_SHORT).show();
        Log.d("MainActivity", "Data from Fragment: " + data);

        // Update data that can be passed back to fragment
        fragmentDataFromActivity = "Updated: " + data;
    }

    //C: Fragment → Fragment (via Activity)
    @Override
    public void onSendDataToFragment3(String data) {
        dataForFragment3 = data;

        // Update Fragment 3 if it's currently visible
        Fragment currentFragment = getSupportFragmentManager()
                .findFragmentById(R.id.fragmentContainer);

        if (currentFragment instanceof ThirdFragment) {
            ((ThirdFragment) currentFragment).updateReceivedData(data);
        }

        Toast.makeText(this, "数据已经传到了消息界面: " + data, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("MainActivity", "onSaveInstanceState called - Lifecycle: " +
                "after onPause, before onStop");

        // Save current state
        outState.putString("fragment_data", fragmentDataFromActivity);
        outState.putString("fragment3_data", dataForFragment3);

        int checkedId = radioGroup.getCheckedRadioButtonId();
        outState.putInt("checked_radio", checkedId);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.d("MainActivity", "onRestoreInstanceState called");

        fragmentDataFromActivity = savedInstanceState.getString("fragment_data", "");
        dataForFragment3 = savedInstanceState.getString("fragment3_data", "");

        int checkedId = savedInstanceState.getInt("checked_radio", R.id.radioFragment1);
        radioGroup.check(checkedId);

        Log.d("MainActivity", "恢复选中的RadioButton: " + checkedId);
        Log.d("MainActivity", "恢复后当前Fragment应该是: " +
                (checkedId == R.id.radioFragment1 ? "Fragment 1" :
                        checkedId == R.id.radioFragment2 ? "Fragment 2" :
                                checkedId == R.id.radioFragment3 ? "Fragment 3" : "Fragment 4"));
    }
    @Override
    protected void onPause() {
        super.onPause();
        Log.d("MainActivity", "onPause 被调用");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("MainActivity", "onStop 被调用");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("MainActivity", "onDestroy 被调用");
    }
}