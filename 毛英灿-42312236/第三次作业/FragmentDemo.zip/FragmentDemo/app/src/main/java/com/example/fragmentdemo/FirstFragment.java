package com.example.fragmentdemo;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class FirstFragment extends Fragment {

    private static final String ARG_INITIAL_DATA = "initial_data";
    private FragmentCallback callback;
    private TextView tvReceivedData;
    private EditText etFragmentData;

    public interface FragmentCallback {
        void onDataReceivedFromFragment(String data);
    }

    public static FirstFragment newInstance(String initialData) {
        FirstFragment fragment = new FirstFragment();
        Bundle args = new Bundle();
        args.putString(ARG_INITIAL_DATA, initialData);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof FragmentCallback) {
            callback = (FragmentCallback) context;
        } else {
            throw new RuntimeException(context + " must implement FragmentCallback");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        tvReceivedData = view.findViewById(R.id.tvReceivedData);
        etFragmentData = view.findViewById(R.id.etFragmentData);
        Button btnSendToActivity = view.findViewById(R.id.btnSendToActivity);

        // Receive initial data from Activity
        if (getArguments() != null) {
            String initialData = getArguments().getString(ARG_INITIAL_DATA);
            tvReceivedData.setText("Activity传来的数据: " + initialData);
        }

        btnSendToActivity.setOnClickListener(v -> {
            String data = etFragmentData.getText().toString();
            if (!data.isEmpty() && callback != null) {
                callback.onDataReceivedFromFragment("从首页传来: " + data);
            }
        });

        return view;
    }
}
