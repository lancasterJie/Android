package com.example.fragmentdemo;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class FourthFragment extends Fragment {

    private static final String KEY_DISPLAY_TEXT = "display_text";
    private static final String KEY_INPUT_TEXT = "input_text";

    private EditText etInput;
    private TextView tvDisplay;
    private Button btnShowText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("FourthFragment", "onCreateView 开始");

        View view = inflater.inflate(R.layout.fragment_fourth, container, false);

        etInput = view.findViewById(R.id.etInput);
        tvDisplay = view.findViewById(R.id.tvDisplay);
        btnShowText = view.findViewById(R.id.btnShowText);

        Log.d("FourthFragment", "视图初始化完成");

        // 恢复保存的状态
        if (savedInstanceState != null) {
            String savedDisplayText = savedInstanceState.getString(KEY_DISPLAY_TEXT, "");
            String savedInputText = savedInstanceState.getString(KEY_INPUT_TEXT, "");

            Log.d("FourthFragment", "从Bundle恢复数据 - Display: '" + savedDisplayText + "', Input: '" + savedInputText + "'");

            tvDisplay.setText(savedDisplayText);
            etInput.setText(savedInputText);

            Toast.makeText(getActivity(), "数据已恢复!", Toast.LENGTH_LONG).show();
        } else {
            Log.d("FourthFragment", "没有保存的数据需要恢复");
        }

        // 按钮点击事件
        btnShowText.setOnClickListener(v -> {
            String inputText = etInput.getText().toString();
            tvDisplay.setText(inputText);
            Log.d("FourthFragment", "按钮点击 - 设置TextView: '" + inputText + "'");
            Toast.makeText(getActivity(), "已设置文本: " + inputText, Toast.LENGTH_SHORT).show();
        });

        Log.d("FourthFragment", "onCreateView 完成");
        return view;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        String displayText = tvDisplay.getText().toString();
        String inputText = etInput.getText().toString();

        Log.d("FourthFragment", "保存数据到Bundle - Display: '" + displayText + "', Input: '" + inputText + "'");

        outState.putString(KEY_DISPLAY_TEXT, displayText);
        outState.putString(KEY_INPUT_TEXT, inputText);

        Toast.makeText(getActivity(), "数据已保存!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d("FourthFragment", "onViewCreated 被调用");
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Log.d("FourthFragment", "onActivityCreated 被调用");

        if (savedInstanceState != null) {
            Log.d("FourthFragment", "onActivityCreated中有保存的状态");
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d("FourthFragment", "onDestroyView 被调用");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d("FourthFragment", "onStart 被调用");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("FourthFragment", "onResume 被调用");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("FourthFragment", "onPause 被调用");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("FourthFragment", "onStop 被调用");
    }
}