package com.example.fragmentdemo;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // 隐藏 ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        TextView tvUserInfo = findViewById(R.id.tvUserInfo);
        Button btnBack = findViewById(R.id.btnBack);

        // Receive data from MainActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String userName = extras.getString("user_name", "Unknown");
            int userAge = extras.getInt("user_age", 0);
            boolean isStudent = extras.getBoolean("is_student", false);

            String userInfo = String.format(
                    "用户名: %s\n年龄: %d\n是否学生: %s",
                    userName, userAge, isStudent ? "是" : "否"
            );

            tvUserInfo.setText(userInfo);
        }

        btnBack.setOnClickListener(v -> finish());
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("DetailActivity", "onSaveInstanceState called");
    }
}