package com.example.notepadapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecordListActivity extends AppCompatActivity {
    private ListView listView;
    private RecordDao recordDao;
    private List<Record> records;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_list);

        // 初始化视图
        initViews();

        // 初始化数据库操作类
        recordDao = new RecordDao(this);

        // 加载记录列表
        loadRecords();

        // 设置列表点击监听器
        setupListViewListener();

        Toast.makeText(this, "记录列表", Toast.LENGTH_SHORT).show();
    }

    /**
     * 初始化视图组件
     */
    private void initViews() {
        listView = findViewById(R.id.listView);
    }

    /**
     * 加载记录列表
     */
    private void loadRecords() {
        // 从数据库获取所有记录
        records = recordDao.getAllRecords();

        // 如果没有记录，显示提示
        if (records.isEmpty()) {
            Toast.makeText(this, "暂无记录", Toast.LENGTH_SHORT).show();
        }

        // 准备适配器数据
        List<Map<String, String>> data = new ArrayList<>();
        for (Record record : records) {
            Map<String, String> map = new HashMap<>();
            map.put("title", record.getTitle());
            map.put("time", "创建时间: " + record.getTime());
            data.add(map);
        }

        // 创建适配器
        SimpleAdapter adapter = new SimpleAdapter(
                this,
                data,
                R.layout.item_record,
                new String[]{"title", "time"},
                new int[]{R.id.tvTitle, R.id.tvTime}
        );

        // 设置适配器
        listView.setAdapter(adapter);
    }

    /**
     * 设置列表视图的点击和长按监听器
     */
    private void setupListViewListener() {
        // 点击项查看详情
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Record record = records.get(position);
            Intent intent = new Intent(RecordListActivity.this, RecordDetailActivity.class);
            intent.putExtra("record_id", record.getId());
            startActivity(intent);
        });

        // 长按项删除记录
        listView.setOnItemLongClickListener((parent, view, position, id) -> {
            Record record = records.get(position);

            // 删除记录
            recordDao.deleteRecord(record.getId());

            // 显示删除成功消息
            Toast.makeText(this, "记录已删除: " + record.getTitle(), Toast.LENGTH_SHORT).show();

            // 重新加载列表
            loadRecords();

            return true; // 消费事件
        });
    }

    /**
     * 当Activity恢复时重新加载数据
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadRecords(); // 重新加载数据
    }
}