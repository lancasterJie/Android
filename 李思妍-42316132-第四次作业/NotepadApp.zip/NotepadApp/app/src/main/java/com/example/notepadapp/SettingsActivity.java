package com.example.notepadapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private CheckBox cbAutoSave;
    private EditText etUserName, etPassword;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // 初始化视图
        initViews();

        // 初始化SharedPreferences
        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);

        // 加载设置
        loadSettings();

        // 设置按钮点击监听器
        setupClickListeners();

        Toast.makeText(this, "设置界面", Toast.LENGTH_SHORT).show();
    }

    /**
     * 初始化视图组件
     */
    private void initViews() {
        cbAutoSave = findViewById(R.id.cbAutoSave);
        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
    }

    /**
     * 加载保存的设置
     */
    private void loadSettings() {
        // 从SharedPreferences读取设置
        boolean autoSave = sharedPreferences.getBoolean("auto_save", false);
        String userName = sharedPreferences.getString("user_name", "");
        String password = sharedPreferences.getString("passwd", "");

        // 更新UI
        cbAutoSave.setChecked(autoSave);
        etUserName.setText(userName);
        etPassword.setText(password);
    }

    /**
     * 设置按钮点击监听器
     */
    private void setupClickListeners() {
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);
        btnSaveSettings.setOnClickListener(v -> saveSettings());
    }

    /**
     * 保存设置
     */
    private void saveSettings() {
        // 获取输入的值
        boolean autoSave = cbAutoSave.isChecked();
        String userName = etUserName.getText().toString();
        String password = etPassword.getText().toString();

        // 保存到SharedPreferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("auto_save", autoSave);
        editor.putString("user_name", userName);
        editor.putString("passwd", password);
        editor.apply();

        Toast.makeText(this, "设置保存成功", Toast.LENGTH_SHORT).show();

        // 返回到主界面
        finish();
    }

    /**
     * 处理返回按钮点击
     */
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}