package com.example.notepadapp;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RecordDetailActivity extends AppCompatActivity {
    private TextView tvTitle, tvContent, tvTime;
    private RecordDao recordDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_detail);

        // 初始化视图
        initViews();

        // 初始化数据库操作类
        recordDao = new RecordDao(this);

        // 获取传递的记录ID
        int recordId = getIntent().getIntExtra("record_id", -1);

        if (recordId != -1) {
            // 加载记录详情
            loadRecordDetail(recordId);
        } else {
            Toast.makeText(this, "记录ID无效", Toast.LENGTH_SHORT).show();
            finish(); // 关闭界面
        }
    }

    /**
     * 初始化视图组件
     */
    private void initViews() {
        tvTitle = findViewById(R.id.tvDetailTitle);
        tvContent = findViewById(R.id.tvDetailContent);
        tvTime = findViewById(R.id.tvDetailTime);
    }

    /**
     * 加载记录详情
     */
    private void loadRecordDetail(int recordId) {
        // 从数据库获取记录
        Record record = recordDao.getRecordById(recordId);

        if (record != null) {
            // 显示记录详情
            tvTitle.setText(record.getTitle());
            tvContent.setText(record.getContent());
            tvTime.setText("创建时间: " + record.getTime());

            // 设置界面标题
            if (getSupportActionBar() != null) {
                getSupportActionBar().setTitle("记录详情");
            }
        } else {
            Toast.makeText(this, "记录不存在", Toast.LENGTH_SHORT).show();
            finish(); // 关闭界面
        }
    }

    /**
     * 处理返回按钮点击
     */
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}