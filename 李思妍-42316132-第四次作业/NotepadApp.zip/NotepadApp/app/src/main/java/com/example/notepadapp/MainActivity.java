package com.example.notepadapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText etContent;
    private TextView tvWelcome;
    private static final String FILE_NAME = "note.txt";
    private SharedPreferences sharedPreferences;
    private RecordDao recordDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化视图
        initViews();

        // 初始化数据库操作类
        recordDao = new RecordDao(this);

        // 初始化SharedPreferences
        sharedPreferences = getSharedPreferences("settings", MODE_PRIVATE);

        // 加载用户信息
        loadUserInfo();

        // 设置按钮点击监听器
        setupClickListeners();

        Toast.makeText(this, "应用启动成功", Toast.LENGTH_SHORT).show();
    }

    /**
     * 初始化视图组件
     */
    private void initViews() {
        etContent = findViewById(R.id.etContent);
        tvWelcome = findViewById(R.id.tvWelcome);
    }

    /**
     * 设置按钮点击监听器
     */
    private void setupClickListeners() {
        // 保存到文件按钮
        findViewById(R.id.btnSaveToFile).setOnClickListener(v -> saveToFile());

        // 从文件加载按钮
        findViewById(R.id.btnLoadFromFile).setOnClickListener(v -> loadFromFile());

        // 保存到数据库按钮
        findViewById(R.id.btnSaveToDb).setOnClickListener(v -> saveToDatabase());
    }

    /**
     * 加载用户信息
     */
    private void loadUserInfo() {
        String userName = sharedPreferences.getString("user_name", "Guest");
        tvWelcome.setText("欢迎, " + userName + "!");
    }

    /**
     * 保存内容到文件
     */
    private void saveToFile() {
        String text = etContent.getText().toString();
        if (text.isEmpty()) {
            Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        try (FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE)) {
            fos.write(text.getBytes());
            Toast.makeText(this, "内容已保存到文件", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "保存失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    /**
     * 从文件加载内容
     */
    private void loadFromFile() {
        try (FileInputStream fis = openFileInput(FILE_NAME)) {
            byte[] buffer = new byte[fis.available()];
            fis.read(buffer);
            String text = new String(buffer);
            etContent.setText(text);
            Toast.makeText(this, "内容已从文件加载", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "文件不存在或读取失败", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    /**
     * 保存内容到数据库
     */
    private void saveToDatabase() {
        String content = etContent.getText().toString();
        if (content.isEmpty()) {
            Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // 生成标题（取前10个字符）
        String title = content.length() > 10 ? content.substring(0, 10) + "..." : content;

        // 生成当前时间
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(new Date());

        // 创建记录对象
        Record record = new Record(title, content, time);

        // 保存到数据库
        long id = recordDao.addRecord(record);

        if (id != -1) {
            Toast.makeText(this, "记录保存成功，ID: " + id, Toast.LENGTH_SHORT).show();
            etContent.setText(""); // 清空编辑框
        } else {
            Toast.makeText(this, "记录保存失败", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 创建选项菜单
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    /**
     * 处理菜单项点击
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_settings) {
            // 跳转到设置界面
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        } else if (id == R.id.menu_records) {
            // 跳转到记录列表界面
            startActivity(new Intent(this, RecordListActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * 当Activity恢复时调用
     */
    @Override
    protected void onResume() {
        super.onResume();

        // 重新加载用户信息
        loadUserInfo();

        // 检查是否开启自动保存
        boolean autoSave = sharedPreferences.getBoolean("auto_save", false);
        if (autoSave) {
            // 自动从文件加载内容
            loadFromFile();
        }
    }

    /**
     * 当Activity暂停时调用
     */
    @Override
    protected void onPause() {
        super.onPause();

        // 检查是否开启自动保存
        boolean autoSave = sharedPreferences.getBoolean("auto_save", false);
        if (autoSave) {
            // 自动保存内容到文件
            saveToFile();
        }
    }
}