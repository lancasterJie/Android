package com.example.activitynavigator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button b1;
    Button b2;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        b1=findViewById(R.id.button1);
        b1.setOnClickListener(new MyListener());
        b2=findViewById(R.id.button2);
        b2.setOnClickListener(new MyListener());
        tv=findViewById(R.id.tv);
    }


    class MyListener implements View.OnClickListener{//设置监听器
        @Override
        public void onClick(View view){
            if(view.getId()==R.id.button1){//普通启动方式，仅用于跳转页面
                Intent it=new Intent(MainActivity.this,SecondActivity.class);
                startActivity(it);
            }
            else if (view.getId()==R.id.button2) {//带返回结果的启动方式，除了跳转页面，还期望从ThirdActivity 关闭时获取返回的数据。
                Intent it = new Intent(MainActivity.this, ThirdActivity.class);
                startActivityForResult(it, 101);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){//启动ThirdActivity
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode==3){//被启动的 Activity 返回的结果码（用于判断操作结果）
            if (requestCode==101){//启动 Activity 时传入的请求码（用于区分不同的跳转来源）
                String resultstring=data.getStringExtra("result");
                tv.setText(resultstring);
            }
        }
    }
}