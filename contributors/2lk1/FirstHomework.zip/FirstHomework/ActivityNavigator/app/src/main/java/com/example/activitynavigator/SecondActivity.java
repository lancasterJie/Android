package com.example.activitynavigator;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SecondActivity extends AppCompatActivity {
    Button back;
    Button im;
    private static final String ACTION_VIEW_THIRD = "com.example.action.VIEW_THIRD_ACTIVITY";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        back=findViewById(R.id.back);
        im=findViewById(R.id.im);

        back.setOnClickListener(new View.OnClickListener(){//设置监听器
                @Override
                public void onClick(View view){
                    Intent it=new Intent();
                    finish();
               }
        });
        im.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent it=new Intent();
                it.setAction(ACTION_VIEW_THIRD);
                it.addCategory(Intent.CATEGORY_DEFAULT);
                startActivity(it) ;
            }

        });
    }
}