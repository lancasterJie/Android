package com.example.notepad;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.appcompat.app.AppCompatActivity;

public class RecordListActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    DatabaseHelper dpHelper;
    EditText edID, edName, edAge;
    Button btnAdd, btnView, btnUpdate, btnDelete;
    TextView resultView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_list);
        setupBottomNavigation();

        dpHelper = new DatabaseHelper(this);
        edID = findViewById(R.id.et_ID);  // 添加ID输入框引用
        edName = findViewById(R.id.et_name);
        edAge = findViewById(R.id.et_age);

        btnAdd = findViewById(R.id.btn_add);
        btnAdd.setOnClickListener(v -> {
            String name = edName.getText().toString();
            String ageStr = edAge.getText().toString();
            if(!name.isEmpty() && !ageStr.isEmpty()){
                try {
                    int age = Integer.parseInt(ageStr);
                    long id = dpHelper.addStudent(name, age);
                    if(id != -1) {
                        Toast.makeText(this, "Add Student With ID: " + id, Toast.LENGTH_LONG).show();
                        clearInputs();
                    } else {
                        Toast.makeText(this, "Fail To Add Student", Toast.LENGTH_LONG).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid age", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
            }
        });

        btnView = findViewById(R.id.btn_view);
        btnView.setOnClickListener(v -> {
            String idStr = edID.getText().toString();
            if(!idStr.isEmpty()){
                try{
                    int id = Integer.parseInt(idStr);
                    viewSingleStudent(id);
                } catch (NumberFormatException e){
                    Toast.makeText(this, "Please enter a valid ID", Toast.LENGTH_LONG).show();
                }
            } else {
                viewAllStudents();
            }
        });

        btnUpdate = findViewById(R.id.btn_update);
        btnUpdate.setOnClickListener(v -> {
            updateStudent();
        });

        btnDelete = findViewById(R.id.btn_delete);
        btnDelete.setOnClickListener(v -> {
            deleteStudent();
        });

        resultView = findViewById(R.id.tv_result);

        // 添加退出登录按钮功能
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> {
            finish(); // 或者跳转到登录页面
        });
    }

    private void viewSingleStudent(int id) {
        Cursor cursor = dpHelper.getStudentById(id);
        if (cursor.getCount() == 0) {
            resultView.setText("No student found with ID: " + id);
            cursor.close();
            return;
        }

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Student Details:\n\n");

        if (cursor.moveToFirst()) {
            int studentId = cursor.getInt(0);
            String name = cursor.getString(1);
            int age = cursor.getInt(2);
            stringBuilder.append("ID: ").append(studentId)
                    .append("\nName: ").append(name)
                    .append("\nAge: ").append(age);
        }
        cursor.close();
        resultView.setText(stringBuilder.toString());
    }

    private void viewAllStudents() {
        Cursor cursor = dpHelper.getAllStudent();
        if (cursor.getCount() == 0) {
            resultView.setText("No students found");
            cursor.close();
            return;
        }

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Students List:\n\n");

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            int age = cursor.getInt(2);
            stringBuilder.append("ID: ").append(id)
                    .append(", Name: ").append(name)
                    .append(", Age: ").append(age)
                    .append("\n");
        }
        cursor.close();
        resultView.setText(stringBuilder.toString());
    }

    private void updateStudent() {
        String idStr = edID.getText().toString();
        String name = edName.getText().toString();
        String ageStr = edAge.getText().toString();

        if (!idStr.isEmpty() && !name.isEmpty() && !ageStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                int age = Integer.parseInt(ageStr);
                int result = dpHelper.updateStudent(id, name, age);
                if (result > 0) {
                    Toast.makeText(this, "Student updated successfully", Toast.LENGTH_LONG).show();
                    clearInputs();
                    viewAllStudents(); // 刷新显示
                } else {
                    Toast.makeText(this, "Update failed - Student not found", Toast.LENGTH_LONG).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid ID and age", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_LONG).show();
        }
    }

    private void deleteStudent() {
        String idStr = edID.getText().toString();
        if (!idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                int result = dpHelper.deleteStudent(id);
                if (result > 0) {
                    Toast.makeText(this, "Student deleted successfully", Toast.LENGTH_LONG).show();
                    clearInputs();
                    viewAllStudents(); // 刷新显示
                } else {
                    Toast.makeText(this, "Delete failed - Student not found", Toast.LENGTH_LONG).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter a valid ID", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Please enter Student ID", Toast.LENGTH_LONG).show();
        }
    }

    private void clearInputs() {
        edID.setText("");
        edName.setText("");
        edAge.setText("");
    }

    private void setupBottomNavigation() {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.menu_records);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();

            if (itemId == R.id.menu_home) {
                Intent intent = new Intent(RecordListActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
                return true;
            } else if (itemId == R.id.menu_records) {
                return true;
            }
            return false;
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }
}