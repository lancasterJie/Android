package com.example.application;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetailActivity extends AppCompatActivity {
    private TextView tvUserInfo;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        tvUserInfo = findViewById(R.id.tv_user_info);
        btn=findViewById(R.id.btn_back);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 关闭当前Activity，返回栈会自动回到上一个Activity（主Activity）
                finish();
            }
        });
        // 从Intent中获取Bundle
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            String username = bundle.getString("username");
            int age = bundle.getInt("age");
            boolean isStudent = bundle.getBoolean("is_student");

            String userInfo = String.format("用户名: %s\n年龄: %d\n学生: %s",
                    username, age, isStudent ? "是" : "否");
            tvUserInfo.setText(userInfo);
        }
    }

}