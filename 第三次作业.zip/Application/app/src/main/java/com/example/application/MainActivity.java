package com.example.application;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity implements DataFragment.OnDataProcessedListener {

    private RadioGroup radioGroup;
    private FrameLayout fragmentContainer;
    private FrameLayout dataFragmentContainer;

    private HomeFragment homeFragment;
    private SearchFragment searchFragment;
    private ProfileFragment profileFragment;
    private SettingsFragment settingsFragment;
    private DataFragment dataFragment;

    private EditText etUsername, etAge;
    private CheckBox cbIsStudent;
    private TextView tvFragmentResult;
    private EditText etMainInput;
    private TextView tvMainDisplay;
    private Button btnUpdateText;
    Button btn ;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn.findViewById(R.id.btn);

        initializeViews();
        setupFragments();
        setupRadioGroupListener();
        setupClickListeners();

        AirplanModeReceiver airplanModeReceiver=new AirplanModeReceiver();
        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction("android.intent.action.AIRPLANE_MODE");
        registerReceiver(airplanModeReceiver,intentFilter);

        // 状态恢复
        if (savedInstanceState != null) {
            restoreState(savedInstanceState);
        }

        System.out.println("onCreate被调用");
    }

    class AirplanModeReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context,Intent intent){
            Toast.makeText(context,"飞行模式",Toast.LENGTH_LONG).show();
        }
    }
    class Mylistener implements View.OnClickListener{
        @Override
        public void onClick(View view){
            if(view.getId()==R.id.btn){
                Intent it=new Intent("com.example.broadcast");
                it.setComponent(new ComponentName("com.example.broadcast" ,"com.example.broadcast.MyReceiver"));
                sendBroadcast(it,null);
            }
        }
    }
    private void initializeViews() {
        // 状态保存相关视图
        etMainInput = findViewById(R.id.editTextText);
        tvMainDisplay = findViewById(R.id.tv);
        btnUpdateText = findViewById(R.id.btn_update_text);

        // 数据传递相关视图
        etUsername = findViewById(R.id.et_username);
        etAge = findViewById(R.id.et_age);
        cbIsStudent = findViewById(R.id.cb_is_student);
        tvFragmentResult = findViewById(R.id.tv_fragment_result);

        // Fragment容器
        radioGroup = findViewById(R.id.radioGroup);
        fragmentContainer = findViewById(R.id.fragmentContainer);
        dataFragmentContainer = findViewById(R.id.data_fragment_container);
    }

    private void setupClickListeners() {
        // 状态保存演示按钮
        btnUpdateText.setOnClickListener(v -> {
            String inputText = etMainInput.getText().toString();
            if (!inputText.isEmpty()) {
                tvMainDisplay.setText("当前输入: " + inputText);
                Toast.makeText(this, "内容已更新，旋转屏幕测试状态保存", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "请输入内容", Toast.LENGTH_SHORT).show();
            }
        });

        // 数据传递按钮
        Button btnSendToFragment = findViewById(R.id.btn_send_to_fragment);
        btnSendToFragment.setOnClickListener(v -> sendDataToFragment());

        Button btnSendToActivity = findViewById(R.id.btn_send_to_activity);
        btnSendToActivity.setOnClickListener(v -> sendDataToDetailActivity());
    }

    private void setupFragments() {
        homeFragment = new HomeFragment();
        searchFragment = new SearchFragment();
        profileFragment = new ProfileFragment();
        settingsFragment = new SettingsFragment();
        dataFragment = new DataFragment();

        // 初始化时添加DataFragment但隐藏
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.data_fragment_container, dataFragment)
                .hide(dataFragment)
                .commit();

        // 默认显示HomeFragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, homeFragment)
                .commit();
    }

    private void setupRadioGroupListener() {
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            Fragment selectedFragment = null;

            if (checkedId == R.id.radioHome) {
                selectedFragment = homeFragment;
            } else if (checkedId == R.id.radioSearch) {
                selectedFragment = searchFragment;
            } else if (checkedId == R.id.radioProfile) {
                selectedFragment = profileFragment;
            } else if (checkedId == R.id.radioSettings) {
                selectedFragment = settingsFragment;
            }

            if (selectedFragment != null) {
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragmentContainer, selectedFragment)
                        .commit();
            }
        });
    }

    // 场景A: Activity → Activity 数据传输
    private void sendDataToDetailActivity() {
        if (!validateInput()) return;

        String username = etUsername.getText().toString();
        int age = Integer.parseInt(etAge.getText().toString());
        boolean isStudent = cbIsStudent.isChecked();

        Bundle bundle = new Bundle();
        bundle.putString("username", username);
        bundle.putInt("age", age);
        bundle.putBoolean("is_student", isStudent);

        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);

        Toast.makeText(this, "数据发送到DetailActivity", Toast.LENGTH_SHORT).show();
    }

    // 场景B: Activity → Fragment 数据传输
    private void sendDataToFragment() {
        if (!validateInput()) return;

        String username = etUsername.getText().toString();
        int age = Integer.parseInt(etAge.getText().toString());
        boolean isStudent = cbIsStudent.isChecked();

        Bundle bundle = new Bundle();
        bundle.putString("username", username);
        bundle.putInt("age", age);
        bundle.putBoolean("is_student", isStudent);

        // 显示DataFragment容器
        dataFragmentContainer.setVisibility(View.VISIBLE);

        // 显示DataFragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // 先隐藏其他可能的fragment
        if (dataFragment.isHidden()) {
            transaction.show(dataFragment);
        }

        // 传递数据给DataFragment
        dataFragment.setInitialData(bundle);

        transaction.commit();

        Toast.makeText(this, "数据已发送到DataFragment", Toast.LENGTH_SHORT).show();
    }

    private boolean validateInput() {
        String username = etUsername.getText().toString();
        String ageStr = etAge.getText().toString();

        if (username.isEmpty() || ageStr.isEmpty()) {
            Toast.makeText(this, "请填写用户名和年龄", Toast.LENGTH_SHORT).show();
            return false;
        }

        try {
            int age = Integer.parseInt(ageStr);
            if (age <= 0 || age > 150) {
                Toast.makeText(this, "请输入合理的年龄", Toast.LENGTH_SHORT).show();
                return false;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "年龄必须是数字", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    // 场景B: Fragment → Activity 回调
    @Override
    public void onDataProcessed(String processedData) {
        tvFragmentResult.setText("Fragment处理结果: " + processedData);
        Toast.makeText(this, "收到Fragment回调数据", Toast.LENGTH_SHORT).show();

        // 场景C: Fragment → Fragment 通信示例
        // 这里可以将处理后的数据传递给其他Fragment
        if (profileFragment != null && profileFragment.isAdded()) {
            // 可以通过Bundle或接口传递数据给其他Fragment
            Bundle resultBundle = new Bundle();
            resultBundle.putString("processed_result", processedData);
            // profileFragment.updateData(resultBundle);
        }
    }

    private void restoreState(Bundle savedInstanceState) {
        String savedText = savedInstanceState.getString("edittext_content");
        String savedDisplay = savedInstanceState.getString("textview_content");
        String savedUsername = savedInstanceState.getString("username");
        String savedAge = savedInstanceState.getString("age");
        boolean savedIsStudent = savedInstanceState.getBoolean("is_student", false);

        if (savedText != null) etMainInput.setText(savedText);
        if (savedDisplay != null) tvMainDisplay.setText(savedDisplay);
        if (savedUsername != null) etUsername.setText(savedUsername);
        if (savedAge != null) etAge.setText(savedAge);
        cbIsStudent.setChecked(savedIsStudent);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        System.out.println("onSaveInstanceState被调用 - 在onStop之前、onPause之后");

        // 保存状态数据
        outState.putString("edittext_content", etMainInput.getText().toString());
        outState.putString("textview_content", tvMainDisplay.getText().toString());
        outState.putString("username", etUsername.getText().toString());
        outState.putString("age", etAge.getText().toString());
        outState.putBoolean("is_student", cbIsStudent.isChecked());
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        System.out.println("onRestoreInstanceState被调用 - 在onStart之后");
    }

    @Override
    protected void onPause() {
        super.onPause();
        System.out.println("onPause被调用");
    }

    @Override
    protected void onStop() {
        super.onStop();
        System.out.println("onStop被调用");
    }

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("onStart被调用");
    }

    @Override
    protected void onResume() {
        super.onResume();
        System.out.println("onResume被调用");
    }
}