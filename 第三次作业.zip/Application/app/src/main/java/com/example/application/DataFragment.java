package com.example.application;
import com.example.application.R;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.text.BreakIterator;

public class DataFragment extends Fragment {
    private TextView tvFragmentData;
    private Button btnProcessData;
    private OnDataProcessedListener listener;

    private String username;
    private int age;
    private boolean isStudent;

    // Fragment → Activity 回调接口
    public interface OnDataProcessedListener {
        void onDataProcessed(String processedData);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            listener = (OnDataProcessedListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + " must implement OnDataProcessedListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_data, container, false);

        tvFragmentData = view.findViewById(R.id.tv_fragment_data);
        btnProcessData = view.findViewById(R.id.btn_process_data);

        btnProcessData.setOnClickListener(v -> processData());

        // 如果已经有数据，立即显示
        if (username != null) {
            displayData();
        }

        return view;
    }


    // Activity → Fragment: 设置初始数据
    public void setInitialData(Bundle bundle) {
        if (bundle != null) {
            username = bundle.getString("username");
            age = bundle.getInt("age");
            isStudent = bundle.getBoolean("is_student");

            // 确保Fragment视图已创建后再更新UI
            if (isAdded() && getView() != null) {
                displayData();
            }
        }
    }

    private void displayData() {
        String data = String.format("接收到的数据:\n用户名: %s\n年龄: %d\n学生: %s",
                username, age, isStudent ? "是" : "否");
        tvFragmentData.setText(data);
    }

    // Fragment → Activity: 处理数据并回调
    private void processData() {
        if (username != null) {
            String processedData = String.format("%s-%d-%s",
                    username.toUpperCase(),
                    age + 5,
                    isStudent ? "STUDENT" : "NOT_STUDENT");

            if (listener != null) {
                listener.onDataProcessed(processedData);
            }
        }
    }
}
