package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class SecondActivity extends AppCompatActivity {

    private Button btnBackToMain;
    private Button btnImplicitJump;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        btnBackToMain = findViewById(R.id.btn_back_to_main);
        btnImplicitJump = findViewById(R.id.btn_implicit_jump);
    }

    private void setupClickListeners() {
        // 第一部分：返回主页
        btnBackToMain.setOnClickListener(v -> {
            finish();
        });

        // 第二部分：隐式跳转到 ThirdActivity
        btnImplicitJump.setOnClickListener(v -> {
            Intent intent = new Intent();
            // 自定义Action
            intent.setAction("com.example.myapplication2.action.VIEW_THIRD_ACTIVITY");
            intent.addCategory(Intent.CATEGORY_DEFAULT);

            // 检查是否有Activity可以处理这个Intent
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                Toast.makeText(this, "没有找到可以处理该操作的Activity",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}