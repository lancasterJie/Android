package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_THIRD_ACTIVITY = 101;
    private Button btnExplicitJump;
    private Button btnStartForResult;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        btnExplicitJump = findViewById(R.id.btn_explicit_jump);
        btnStartForResult = findViewById(R.id.btn_start_for_result);
        tvResult = findViewById(R.id.tv_result);
    }

    private void setupClickListeners() {
        // 第一部分：显式跳转到 SecondActivity
        btnExplicitJump.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            startActivity(intent);
        });

        // 第三部分：带结果跳转到 ThirdActivity（点击监听）
        btnStartForResult.setOnClickListener(v -> {
            startThirdActivityForResult();
        });

        // 加分项：长按监听器
        btnStartForResult.setOnLongClickListener(v -> {
            Toast.makeText(MainActivity.this, "长按启动了带返回结果的跳转！",
                    Toast.LENGTH_SHORT).show();
            startThirdActivityForResult();
            return true;
        });
    }

    private void startThirdActivityForResult() {
        Intent intent = new Intent(MainActivity.this, ThirdActivity.class);
        startActivityForResult(intent, REQUEST_CODE_THIRD_ACTIVITY);
    }

    // 第三部分：处理返回结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_THIRD_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                // 处理成功返回的结果
                String result = data.getStringExtra("result_data");
                tvResult.setText("返回结果: " + result);
            } else if (resultCode == Activity.RESULT_CANCELED) {
                // 加分项：处理取消操作
                tvResult.setText("用户取消了操作");
            }
        }
    }
}