package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ThirdActivity extends AppCompatActivity {

    private EditText etInput;
    private Button btnReturnResult;
    private Button btnReturnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        initViews();
        setupClickListeners();
    }

    private void initViews() {
        etInput = findViewById(R.id.et_input);
        btnReturnResult = findViewById(R.id.btn_return_result);
        btnReturnCancel = findViewById(R.id.btn_return_cancel);
    }

    private void setupClickListeners() {
        // 第三部分：返回结果
        btnReturnResult.setOnClickListener(v -> {
            String inputText = etInput.getText().toString().trim();

            Intent resultIntent = new Intent();
            // 如果用户没有输入，使用默认文本
            String resultData = inputText.isEmpty() ?
                    "默认返回文本" : inputText;
            resultIntent.putExtra("result_data", resultData);

            setResult(Activity.RESULT_OK, resultIntent);
            finish();
        });

        // 加分项：返回取消
        btnReturnCancel.setOnClickListener(v -> {
            setResult(Activity.RESULT_CANCELED);
            finish();
        });
    }
}