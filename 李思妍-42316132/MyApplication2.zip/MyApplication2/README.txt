项目名称：MyApplication2
学号：42316132
姓名：李思妍

项目描述：
实现了Android Activity之间的三种跳转方式

运行截图：
请查看项目根目录下的 screenshots 文件夹：

screenshots/
├── main_activity.png       - 主界面截图
├── second_activity.png     - SecondActivity界面
├── third_activity.png      - ThirdActivity界面
├── toast_demo.png          - Toast提示效果
└── result_demo.png         - 返回结果展示

截图说明：
1. main_activity.png - 显示主界面的两个按钮和结果显示区域
2. second_activity.png - 显示返回按钮和隐式跳转按钮
3. third_activity.png - 显示输入框、返回结果和返回取消按钮
4. toast_demo.png - 长按按钮时显示的Toast提示
5. result_demo.png - 从ThirdActivity返回后显示的数据

实现功能：
✅ 第一部分：显式跳转
   - MainActivity → SecondActivity 显式跳转
   - SecondActivity 返回主页

✅ 第二部分：隐式跳转
   - SecondActivity → ThirdActivity 隐式跳转
   - 自定义Action: com.example.myapplication2.action.VIEW_THIRD_ACTIVITY

✅ 第三部分：带返回结果的跳转
   - MainActivity ↔ ThirdActivity 数据传递
   - 处理返回结果和取消操作

✅ 加分项：
   - 长按按钮显示Toast提示
   - 返回取消功能

项目结构：
- MainActivity: 主界面
- SecondActivity: 第二界面
- ThirdActivity: 第三界面

运行说明：
1. 用Android Studio打开项目
2. 连接Android设备或启动模拟器
3. 点击运行按钮测试功能